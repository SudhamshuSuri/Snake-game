from turtle import Screen
from snake import Snake
import time
from food import Food
from scoreboard import ScoreBoard

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("My snake game")
screen.tracer(0)

timmy = Snake()
food = Food()
scoreboard = ScoreBoard()

screen.listen()
screen.onkey(timmy.move_up, "Up")
screen.onkey(timmy.move_down, "Down")
screen.onkey(timmy.move_right, "Right")
screen.onkey(timmy.move_left, "Left")

is_game_on = True
while is_game_on:
    screen.update()
    time.sleep(0.1)

    timmy.move()

    # Detect collisions with food
    if timmy.head.distance(food) < 15:
        food.refresh_food()
        timmy.extend()
        scoreboard.increase_score()
        scoreboard.update_scoreboard()

    # Detect collisons with the wall
    if timmy.head.xcor() > 280 or timmy.head.ycor() > 280 or timmy.head.xcor() < -280 or timmy.head.ycor() < -280:
        is_game_on = False
        scoreboard.game_over()

    # Detect collisions with tail
    for segments in timmy.segments:
        if segments == timmy.head:
            pass
        elif timmy.head.distance(segments) < 10:
            is_game_on = False
            scoreboard.game_over()

screen.exitonclick()
